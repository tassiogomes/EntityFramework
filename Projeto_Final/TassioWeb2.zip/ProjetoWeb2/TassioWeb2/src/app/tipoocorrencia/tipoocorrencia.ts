export interface TipoOcorrenciaInterface {
    idTipoOcorrencia?: number,
    nomeTipoOcorrencia: string,
    inativo?: boolean
}